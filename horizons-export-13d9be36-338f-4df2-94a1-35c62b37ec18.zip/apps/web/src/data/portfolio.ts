export const resumeUrl = 'https://horizons-cdn.hostinger.com/13d9be36-338f-4df2-94a1-35c62b37ec18/1d9d37ecd1074e3ef4c85835fff31cdb.pdf';
export const linkedinUrl = 'https://www.linkedin.com/in/anjali-nair-38b265303/';
export const skills = [
 { number: '01', title: 'Artificial intelligence', description: 'From exploring data to building useful, intelligent tools.', items: ['Python', 'scikit-learn', 'TensorFlow', 'PyTorch', 'Keras', 'AI chatbots & API integration'] },
 { number: '02', title: 'Development & data', description: 'Turning ideas into interfaces, workflows, and practical solutions.', items: ['HTML / CSS', 'JavaScript', 'React', 'NumPy', 'Pandas', 'Matplotlib', 'Jupyter / Google Colab', 'n8n / Zapier'] },
 { number: '03', title: 'Cybersecurity', description: 'A security-first mindset, with hands-on vulnerability testing.', items: ['Kali Linux', 'Burp Suite', 'Nmap', 'Wireshark', 'Metasploit', 'OWASP Top 10', 'Bug bounty testing'] },
];
export const projects = [
 { number: '01', title: 'Tron Intelligence', category: 'AI CONSULTANCY · FOUNDER', description: 'An AI consultancy and bespoke software company, founded and registered at 19.', details: 'I designed the service offering around helping businesses and individuals save time, reduce costs, and support growth with AI. My work includes branding, website development, pricing, outreach, discovery calls, pilot-project preparation, and client onboarding.', tags: ['AI strategy', 'Bespoke software', 'Entrepreneurship'] },
 { number: '02', title: 'AI-powered portfolio', category: 'WEB DEVELOPMENT · AI', description: 'A personal portfolio built and launched with a custom AI chatbot.', details: 'A project bringing web development and AI integration together in a personal portfolio experience. The existing website is available below; this new portfolio focuses on showcasing my background and work.', tags: ['Web development', 'Custom chatbot', 'AI integration'], href: 'https://anjalinair.vercel.app/' },
 { number: '03', title: 'Parking app', category: 'PRODUCT DEVELOPMENT', description: 'A practical app project exploring the problem of parking costs.', details: 'Developed a parking app addressing cost issues, applying a problem-solving approach to an everyday challenge. This project reflects my interest in building technology around real needs.', tags: ['Problem solving', 'App development', 'User needs'] },
];
export const experience = [
 { date: 'MAR 2026 — PRESENT', role: 'Founder', company: 'Tron Intelligence', location: 'Liverpool', text: 'Founded an AI consultancy providing tailored software and advice for small businesses, larger organisations, and individuals. Built the business presence and prepared discovery, pilot-project, and onboarding workflows while studying full-time.' },
 { date: 'SEP 2023 — AUG 2026', role: 'Manager', company: 'McDonald’s', location: 'Bath', text: 'Led front-line operations, delegated priorities, trained staff, and translated management directives into practical policies. Supported sales forecasting, health and safety compliance, and consistent customer service.' },
];
export const education = [
 { date: '2025 — PRESENT', title: 'BSc (Hons) Artificial Intelligence', place: 'Liverpool Hope University · Liverpool' },
 { date: '2023 — 2025', title: 'A-Levels', place: 'Oldfield School · Bath', detail: 'Computer Science, Biology, Psychology' },
 { date: '2022 — 2023', title: 'GCSEs', place: 'Kendriya Vidyalaya Pangode · India', detail: 'English, Hindi, Maths, Science, Social Science, Artificial Intelligence' },
];
export const certifications = [
 ['2025', 'NCSC CyberFirst Defenders & Advanced', 'Army Cadets UK · Top Student on both courses'],
 ['2023', 'Bug Bounty Course', 'Cybersecurity training'],
 ['2025', 'First Aid at Work', 'Workplace first aid'],
 ['2026', 'Bronze Navigator Award', 'National Navigation Award Scheme (NNAS)'],
 ['2025 / 2026', 'Shift Management & Leadership', 'McDonald’s'],
];
