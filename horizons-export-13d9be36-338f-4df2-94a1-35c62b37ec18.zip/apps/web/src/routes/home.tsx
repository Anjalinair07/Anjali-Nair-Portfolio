import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { Hero } from '@/components/home/hero';
import { About } from '@/components/home/about';
import { Skills } from '@/components/home/skills';
import { Work } from '@/components/home/work';
import { Journey } from '@/components/home/journey';
import { Gallery } from '@/components/home/gallery';
import { Contact } from '@/components/home/contact';
export function meta({ matches, location }: Route.MetaArgs) {
 return seo({ matches, location }, { title: 'Anjali Nair — AI Student, Builder & Founder', description: 'Meet Anjali Nair, an Artificial Intelligence student at Liverpool Hope University and founder of Tron Intelligence. Explore her work, cybersecurity skills, experience, and achievements.' });
}
export default function HomePage() {
 return <><SiteHeader/><main><Hero/><About/><Skills/><Work/><Journey/><Gallery/><Contact/></main></>;
}
