import { BrainCircuit, Code2, ShieldCheck } from 'lucide-react';
import { skills } from '@/data/portfolio';
const icons = [BrainCircuit, Code2, ShieldCheck];
export function Skills() {
 return <section id="skills" className="section skills-section"><div className="section-heading"><p className="eyebrow">02 / MY TOOLKIT</p><span className="section-note">ALWAYS LEARNING. ALWAYS ITERATING.</span></div><div className="title-row"><h2>Ideas need<br/>the right tools.</h2><p>A growing toolkit for building,<br/>understanding, and securing technology.</p></div><div className="skills-grid">{skills.map((skill, index) => { const Icon = icons[index]; return <article className="skill-panel" key={skill.number}><div className="skill-top"><Icon size={26} strokeWidth={1.4}/><span>{skill.number}</span></div><h3>{skill.title}</h3><p>{skill.description}</p><div className="tags">{skill.items.map(item => <span key={item}>{item}</span>)}</div></article>; })}</div></section>;
}
