import { Mountain, Waves, Trophy, Languages } from 'lucide-react';

const frames = [
	{
		src: 'https://horizons-cdn.hostinger.com/13d9be36-338f-4df2-94a1-35c62b37ec18/35836be9c428d4917dcb657b9a2b78d3.jpg',
		title: 'On the water',
		caption: 'Kayaking · red kit, helmet in hand',
		alt: 'Anjali Nair in a red kayaking jacket holding a helmet on grass',
	},
	{
		src: 'https://horizons-cdn.hostinger.com/13d9be36-338f-4df2-94a1-35c62b37ec18/0aa45ae001d5be5b11434acc35adc673.jpg',
		title: 'Cadet days',
		caption: 'Army Cadets · medal in hand',
		alt: 'Anjali Nair in camouflage uniform and beret holding a medal and giving a thumbs up',
	},
	{
		src: 'https://horizons-cdn.hostinger.com/13d9be36-338f-4df2-94a1-35c62b37ec18/98de1ec7dceece28cd4ef5014ad1ffa4.jpg',
		title: 'On the hills',
		caption: 'Trekking · Bronze Navigator',
		alt: 'Anjali Nair hiking on green hills with a backpack',
	},
];

export function Gallery() {
	return (
		<section id="gallery" className="section gallery-section">
			<div className="section-heading">
				<p className="eyebrow">05 / BEYOND THE SCREEN</p>
				<span className="section-note">A LITTLE LESS CODE. A LITTLE MORE LIFE.</span>
			</div>
			<div className="title-row">
				<h2>
					Not just a
					<br />
					tech person.
				</h2>
				<p>
					Athletics, football, trekking, and swimming.
					<br />
					Curiosity doesn’t stop at the keyboard.
				</p>
			</div>
			<div className="photo-grid">
				{frames.map((frame, index) => (
					<figure className={`photo-frame photo-${index}`} key={frame.title}>
						<img src={frame.src} alt={frame.alt} />
						<span className="photo-number">FRAME / 0{index + 1}</span>
						<figcaption className="photo-caption">
							{frame.title}
							<span>{frame.caption}</span>
						</figcaption>
					</figure>
				))}
			</div>
			<div className="interests-row">
				<div>
					<Mountain size={20} /> Trekking
				</div>
				<div>
					<Waves size={20} /> Swimming
				</div>
				<div>
					<Trophy size={20} /> Athletics & football
				</div>
				<div>
					<Languages size={20} />
					<span>English · Hindi · Malayalam · Tamil</span>
				</div>
			</div>
		</section>
	);
}
