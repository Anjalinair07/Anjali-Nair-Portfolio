import { ArrowDown, ArrowUpRight } from 'lucide-react';

const heroPhoto =
	'https://horizons-cdn.hostinger.com/13d9be36-338f-4df2-94a1-35c62b37ec18/cfefd06d3b0b2f1ab3af187081e3660f.jpg';

export function Hero() {
	return (
		<section id="home" className="hero">
			<div className="hero-topline">
				<span>
					<i className="status-dot" /> OPEN TO TECH & AI OPPORTUNITIES
				</span>
				<span>
					LIVERPOOL, UK <span className="dim">/</span> 53.4084° N
				</span>
			</div>
			<div className="hero-copy">
				<p className="eyebrow">AI STUDENT. BUILDER. CURIOUS BY NATURE.</p>
				<h1>
					Anjali
					<br />
					<span>
						Nair<span className="clay-dot">.</span>
					</span>
				</h1>
				<p className="hero-description">
					Exploring intelligence.
					<br />
					Building things that matter.
				</p>
				<a className="primary-button" href="#work">
					Explore my work <ArrowUpRight size={18} />
				</a>
			</div>
			<figure className="hero-portrait">
				<img src={heroPhoto} alt="Anjali Nair by the waterfront at dusk" />
				<figcaption>
					<span>FRAME / 01</span>
					<span>LIVERPOOL WATERFRONT</span>
				</figcaption>
			</figure>
			<div className="hero-bottom">
				<a href="#about">
					<ArrowDown size={16} /> SCROLL TO DISCOVER
				</a>
				<span>HUMAN CURIOSITY. MACHINE POSSIBILITIES.</span>
				<span className="edition">PORTFOLIO — 2026</span>
			</div>
		</section>
	);
}
