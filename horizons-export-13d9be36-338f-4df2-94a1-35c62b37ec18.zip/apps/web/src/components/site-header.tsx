import { useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { resumeUrl } from '@/data/portfolio';
export function SiteHeader() {
 const [open, setOpen] = useState(false);
 return <header className="site-header"><a className="wordmark" href="#home" aria-label="Anjali Nair home">an<span>.</span></a><nav className={open ? 'navigation is-open' : 'navigation'} aria-label="Main navigation">{[['About', 'about'], ['Skills', 'skills'], ['Work', 'work'], ['Journey', 'journey'], ['Gallery', 'gallery']].map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)}>{label}</a>)}</nav><a className="resume-link" href={resumeUrl} target="_blank" rel="noreferrer">Résumé <ArrowUpRight size={15}/></a><button className="menu-toggle" aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button></header>;
}
